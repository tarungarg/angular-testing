import { HeroesComponent } from "./heroes.component";

describe("HerosCompoennt", () => {
  let component: HeroesComponent;
  let HEROES;
})
