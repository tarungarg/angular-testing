import { StrengthPipe } from "./strength.pipe";

describe('strength pip', () => {
  it('should display weak', () => {
    let pipe = new StrengthPipe()
    expect(pipe.transform(5)).toEqual('5 (weak)')
  })
})
