import { MessageService } from "../message.service";

describe("messageService", () => {
  let service: MessageService

  beforeEach(() => {
    service = new MessageService()
  })
})
